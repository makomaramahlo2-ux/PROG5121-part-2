package com.mycompany.prog5121_poe;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import prog5121.Login;
import prog5121.Message;

public class PROG5121_POE {

    static ArrayList<Message> allMessages = new ArrayList<>();
    static ArrayList<Message> sentMessages = new ArrayList<>();
    static ArrayList<Message> disregardedMessages = new ArrayList<>();
    static ArrayList<Message> storedMessages = new ArrayList<>();

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to QuickChat");
        System.out.println();
        System.out.println("Please register");

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter cellphone number: ");
        String cellPhone = scanner.nextLine();

        Login login = new Login(
                username,
                password,
                cellPhone,
                firstName,
                lastName
        );

        String registrationMessage = login.registerUser();

        System.out.println();
        System.out.println(registrationMessage);

        if (!registrationMessage.equals("User registered successfully.")) {
            scanner.close();
            return;
        }

        System.out.println();
        System.out.println("Please login");

        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        String loginMessage =
                login.returnLoginStatus(
                        loginUsername,
                        loginPassword
                );

        System.out.println();
        System.out.println(loginMessage);

        if (!login.loginUser(loginUsername, loginPassword)) {
            scanner.close();
            return;
        }

        System.out.println();
        System.out.println("Welcome to QuickChat");

        boolean running = true;

        while (running) {

            System.out.println();
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");

            System.out.print("Choose an option: ");
            String option = scanner.nextLine();

            switch (option) {

                case "1":
                    sendMessages(scanner, firstName, lastName);
                    break;

                case "2":
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    running = false;
                    System.out.println("Goodbye!");
                    break;

                case "4":
                    storedMessagesMenu(scanner);
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }

        scanner.close();
    }

    public static void sendMessages(
            Scanner scanner,
            String firstName,
            String lastName) {

        System.out.print("How many messages would you like to enter? ");

        int numberOfMessages = Integer.parseInt(
                scanner.nextLine()
        );

        for (int i = 0; i < numberOfMessages; i++) {

            System.out.println();
            System.out.println("Message " + (i + 1));

            String messageID = generateMessageID();

            System.out.println("Message ID: " + messageID);

            System.out.print("Enter recipient cellphone number: ");
            String recipient = scanner.nextLine();

            Message message = new Message(
                    messageID,
                    i,
                    recipient,
                    ""
            );

            String recipientResult =
                    message.checkRecipientCell();

            System.out.println(recipientResult);

            if (!recipientResult.equals(
                    "Cell phone number successfully captured.")) {

                System.out.println("Message discarded.");
                continue;
            }

            System.out.print("Enter message: ");
            String messageText = scanner.nextLine();

            message = new Message(
                    messageID,
                    i,
                    recipient,
                    messageText
            );

            message.setSender(firstName + " " + lastName);

            String lengthResult =
                    message.checkMessageLength();

            System.out.println(lengthResult);

            if (!lengthResult.equals("Message ready to send.")) {
                continue;
            }

            System.out.println();
            System.out.println("Message Hash: "
                    + message.createMessageHash());

            System.out.println();
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message");

            System.out.print("Choose an option: ");
            String choice = scanner.nextLine();

            String result = message.SentMessage(choice);

            System.out.println(result);

            allMessages.add(message);

            if (choice.equals("1")) {

                sentMessages.add(message);

                System.out.println();
                System.out.println(message.printMessages());

            } else if (choice.equals("2")) {

                disregardedMessages.add(message);

            } else if (choice.equals("3")) {

                storedMessages.add(message);
                message.storeMessage();

                System.out.println();
                System.out.println(message.printMessages());
            }
        }

        System.out.println();
        System.out.println("Total messages sent: "
                + countSentMessages());
    }

    public static String generateMessageID() {

        Random random = new Random();

        long number = Math.abs(
                random.nextLong() % 10000000000L
        );

        return String.format("%010d", number);
    }

    public static int countSentMessages() {

        return sentMessages.size();
    }

    public static void storedMessagesMenu(Scanner scanner) {

        storedMessages.clear();

        Message[] loadedMessages =
                Message.loadStoredMessages();

        for (Message message : loadedMessages) {
            storedMessages.add(message);
        }

        if (storedMessages.isEmpty()) {

            System.out.println();
            System.out.println("No stored messages found.");
            return;
        }

        boolean running = true;

        while (running) {

            System.out.println();
            System.out.println("STORED MESSAGES");
            System.out.println("1) Display sender and recipient");
            System.out.println("2) Display longest message");
            System.out.println("3) Search by message ID");
            System.out.println("4) Search by recipient");
            System.out.println("5) Delete by message hash");
            System.out.println("6) Display report");
            System.out.println("7) Return to main menu");

            System.out.print("Choose an option: ");
            String option = scanner.nextLine();

            switch (option) {

                case "1":
                    displaySenderRecipient();
                    break;

                case "2":
                    displayLongestMessage();
                    break;

                case "3":
                    searchMessageID(scanner);
                    break;

                case "4":
                    searchRecipient(scanner);
                    break;

                case "5":
                    deleteMessage(scanner);
                    break;

                case "6":
                    displayReport();
                    break;

                case "7":
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    public static void displaySenderRecipient() {

        for (Message message : storedMessages) {

            System.out.println();
            System.out.println("Sender: "
                    + message.getSender());

            System.out.println("Recipient: "
                    + message.getRecipient());
        }
    }

    public static void displayLongestMessage() {

        Message longest = storedMessages.get(0);

        for (Message message : storedMessages) {

            if (message.getMessage().length()
                    > longest.getMessage().length()) {

                longest = message;
            }
        }

        System.out.println();
        System.out.println("Longest stored message:");
        System.out.println(longest.getMessage());
    }

    public static void searchMessageID(Scanner scanner) {

        System.out.print("Enter message ID: ");

        String searchID = scanner.nextLine();

        for (Message message : storedMessages) {

            if (message.getMessageID().equals(searchID)) {

                System.out.println();
                System.out.println("Recipient: "
                        + message.getRecipient());

                System.out.println("Message: "
                        + message.getMessage());

                return;
            }
        }

        System.out.println("Message ID not found.");
    }

    public static void searchRecipient(Scanner scanner) {

        System.out.print("Enter recipient: ");

        String recipient = scanner.nextLine();

        boolean found = false;

        for (Message message : storedMessages) {

            if (message.getRecipient().equals(recipient)) {

                System.out.println();
                System.out.println("Message: "
                        + message.getMessage());

                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found for that recipient.");
        }
    }

    public static void deleteMessage(Scanner scanner) {

        System.out.print("Enter message hash: ");

        String hash = scanner.nextLine();

        for (int i = 0; i < storedMessages.size(); i++) {

            Message message = storedMessages.get(i);

            if (message.getMessageHash().equals(hash)) {

                System.out.println(
                        "Message: \""
                        + message.getMessage()
                        + "\" successfully deleted."
                );

                storedMessages.remove(i);

                rewriteStoredMessages();

                return;
            }
        }

        System.out.println("Message hash not found.");
    }

    public static void displayReport() {

        System.out.println();
        System.out.println("STORED MESSAGE REPORT");

        for (Message message : storedMessages) {

            System.out.println();
            System.out.println("Message Hash: "
                    + message.getMessageHash());

            System.out.println("Recipient: "
                    + message.getRecipient());

            System.out.println("Message: "
                    + message.getMessage());
        }
    }

    public static void rewriteStoredMessages() {

        try {

            java.io.FileWriter writer =
                    new java.io.FileWriter(
                            "stored_messages.json"
                    );

            writer.write("[");

            for (int i = 0; i < storedMessages.size(); i++) {

                Message message = storedMessages.get(i);

                writer.write(
                        "{"
                        + "\"messageID\":\""
                        + message.getMessageID()
                        + "\","
                        + "\"messageNumber\":"
                        + i
                        + ","
                        + "\"sender\":\""
                        + message.getSender()
                        + "\","
                        + "\"recipient\":\""
                        + message.getRecipient()
                        + "\","
                        + "\"message\":\""
                        + message.getMessage()
                        .replace("\"", "\\\"")
                        + "\","
                        + "\"messageHash\":\""
                        + message.getMessageHash()
                        + "\","
                        + "\"status\":\"Stored\""
                        + "}"
                );

                if (i < storedMessages.size() - 1) {
                    writer.write(",");
                }
            }

            writer.write("]");
            writer.close();

        } catch (Exception e) {

            System.out.println(
                    "Could not update JSON file."
            );
        }
    }
}