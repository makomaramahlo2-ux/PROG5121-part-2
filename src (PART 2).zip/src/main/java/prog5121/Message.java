package prog5121;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String status;
    private String sender;

    private static int totalMessagesSent = 0;

    public Message() {
    }

    public Message(String messageID, int messageNumber,
                    String recipient, String message) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
        this.status = "";
        this.sender = "User";
    }

    public Message(String messageID, int messageNumber,
                    String recipient, String message,
                    String status, String sender) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.status = status;
        this.sender = sender;
        this.messageHash = createMessageHash();
    }

    public boolean checkMessageID() {
        return messageID != null
                && messageID.length() <= 10;
    }

    public String checkRecipientCell() {

        if (recipient != null
                && recipient.matches("^(\\+27\\d{9}|0\\d{9})$")) {

            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted "
                + "or does not contain an international code. "
                + "Please correct the number and try again.";
    }

    public String checkMessageLength() {

        if (message == null) {
            return "Message ready to send.";
        }

        if (message.length() <= 250) {
            return "Message ready to send.";
        }

        int excess = message.length() - 250;

        return "Message exceeds 250 characters by "
                + excess
                + "; please reduce the size.";
    }

    public String createMessageHash() {

        if (messageID == null || message == null) {
            return "";
        }

        String[] words = message.trim().split("\\s+");

        String firstWord = words[0]
                .replaceAll("[^a-zA-Z0-9]", "");

        String lastWord = "";

        for (int i = words.length - 1; i >= 0; i--) {
            String cleaned = words[i]
                    .replaceAll("[^a-zA-Z0-9]", "");

            if (!cleaned.isEmpty()) {
                lastWord = cleaned;
                break;
            }
        }

        String firstTwoID = messageID.length() >= 2
                ? messageID.substring(0, 2)
                : messageID;

        messageHash = firstTwoID
                + ":"
                + messageNumber
                + ":"
                + firstWord
                + lastWord;

        return messageHash.toUpperCase();
    }

    public String SentMessage(String choice) {

        if (choice.equals("1")) {

            status = "Sent";
            totalMessagesSent++;

            return "Message successfully sent.";

        } else if (choice.equals("2")) {

            status = "Disregarded";

            return "Press 0 to delete the message.";

        } else if (choice.equals("3")) {

            status = "Stored";

            return "Message successfully stored.";

        }

        return "Invalid option.";
    }

    public String SentMessage() {
        return status;
    }

    public String printMessages() {

        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    public int returnTotalMessagess() {
        return totalMessagesSent;
    }

    public void storeMessage() {

        try {

            File file = new File("stored_messages.json");

            String existing = "[]";

            if (file.exists()) {
                existing = Files.readString(file.toPath());
            }

            String newObject = "{"
                    + "\"messageID\":\"" + escape(messageID) + "\","
                    + "\"messageNumber\":" + messageNumber + ","
                    + "\"sender\":\"" + escape(sender) + "\","
                    + "\"recipient\":\"" + escape(recipient) + "\","
                    + "\"message\":\"" + escape(message) + "\","
                    + "\"messageHash\":\"" + escape(messageHash) + "\","
                    + "\"status\":\"Stored\""
                    + "}";

            String updated;

            if (existing.trim().equals("[]")) {
                updated = "[" + newObject + "]";
            } else {
                updated = existing.substring(0, existing.lastIndexOf("]"))
                        + ","
                        + newObject
                        + "]";
            }

            FileWriter writer = new FileWriter(file);
            writer.write(updated);
            writer.close();

        } catch (IOException e) {
            System.out.println("Could not store message: "
                    + e.getMessage());
        }
    }

    private String escape(String value) {

        if (value == null) {
            return "";
        }

        return value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"");
    }

    public static Message[] loadStoredMessages() {

        try {

            Path path = Paths.get("stored_messages.json");

            if (!Files.exists(path)) {
                return new Message[0];
            }

            String json = Files.readString(path);

            Pattern pattern = Pattern.compile(
                    "\\{\\s*"
                    + "\"messageID\":\"(.*?)\","
                    + "\"messageNumber\":(\\d+),"
                    + "\"sender\":\"(.*?)\","
                    + "\"recipient\":\"(.*?)\","
                    + "\"message\":\"(.*?)\","
                    + "\"messageHash\":\"(.*?)\","
                    + "\"status\":\"Stored\""
                    + "\\s*\\}",
                    Pattern.DOTALL);

            Matcher matcher = pattern.matcher(json);

            java.util.ArrayList<Message> messages =
                    new java.util.ArrayList<>();

            while (matcher.find()) {

                Message stored = new Message(
                        matcher.group(1),
                        Integer.parseInt(matcher.group(2)),
                        matcher.group(4),
                        matcher.group(5),
                        "Stored",
                        matcher.group(3)
                );

                messages.add(stored);
            }

            return messages.toArray(new Message[0]);

        } catch (IOException e) {

            return new Message[0];
        }
    }

    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getStatus() {
        return status;
    }

    public String getSender() {
        return sender;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }
}