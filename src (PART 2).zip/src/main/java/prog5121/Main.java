/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121;
import java.util.Scanner;

/**
 *
 * @author MAKOMA RAMAHLO
 */
public class Main {
    
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("=================================");
        System.out.println("       REGISTRATION SYSTEM");
        System.out.println("=================================");

        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        System.out.print("Enter South African cell phone number: ");
        String cellPhone = scanner.nextLine();

        Login login = new Login(
                username,
                password,
                cellPhone,
                firstName,
                lastName
        );

        System.out.println();
        System.out.println(login.registerUser());
    
        if (login.checkUserName()) {
            System.out.println("Username successfully captured.");
        }

        if (login.checkPasswordComplexity()) {
            System.out.println("Password successfully captured.");
        }

        if (login.checkCellPhoneNumber()) {
            System.out.println("Cell phone number successfully added.");
        }

        if (login.checkUserName()
                && login.checkPasswordComplexity()
                && login.checkCellPhoneNumber()) {

            System.out.println();
            System.out.println("------------- LOGIN -------------");

            System.out.print("Enter username: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = scanner.nextLine();

            System.out.println(
                    login.returnLoginStatus(
                            loginUsername,
                            loginPassword
                    )
            );

            if (login.loginUser(loginUsername, loginPassword)) {
                runQuickChat(scanner);
            }
        }

        scanner.close();
    }

    public static void runQuickChat(Scanner scanner) {

        System.out.println();
        System.out.println("=================================");
        System.out.println("       Welcome to QuickChat");
        System.out.println("=================================");

        System.out.print("How many messages would you like to enter? ");
        int numberOfMessages = scanner.nextInt();
        scanner.nextLine();

        int totalMessagesSent = 0;

        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println();
            System.out.println("Message " + i);

            System.out.print("Enter recipient number: ");
            String recipient = scanner.nextLine();

            System.out.print("Enter message: ");
            String messageText = scanner.nextLine();

            Message message = new Message(
                   id,
                   recipient,
                   messageText
            );

            System.out.println();

            if (!message.checkMessageID()) {
                System.out.println("Message ID is invalid.");
                continue;
            }

            System.out.println(message.checkRecipientCell());
            System.out.println(message.checkMessageLength());

            if (message.checkMessageLength().equals("Message ready to send.")
                    && message.checkRecipientCell()
                    .equals("Cell phone number successfully captured.")) {

                System.out.println();
                System.out.println("1. Send Message");
                System.out.println("2. Disregard Message");
                System.out.println("3. Store Message");

                System.out.print("Choose an option: ");
                int option = scanner.nextInt();
                scanner.nextLine();

                System.out.println(message.SentMessage(option));

                if (option == 1) {
                    totalMessagesSent++;

                    System.out.println();
                    System.out.println(message.printMessages());
                }
            }
        }

        System.out.println();
        System.out.println("Total messages sent: "
                + totalMessagesSent);
    }
}